STANDARD = "standard"
STANDARD_FULL_TRANSCRIPTS = "standard_full_transcripts"
FINAL_OUTPUTS = "final_outputs"
FINAL_OUTPUTS2 = "final_outputs2"
